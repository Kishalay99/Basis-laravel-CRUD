<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ATG_User extends Model
{
    //
}
